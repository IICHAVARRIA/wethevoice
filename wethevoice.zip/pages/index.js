import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getAuth, onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';

export default function Home() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        const docSnap = await getDoc(doc(db, 'users', currentUser.uid));
        if (docSnap.exists()) setRole(docSnap.data().role);
      } else {
        setUser(null);
        setRole(null);
      }
    });
    return () => unsubscribe();
  }, []);

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome to WeTheVoice</h1>
      {user ? (
        <>
          <p>Logged in as {user.email} ({role})</p>
          <button onClick={() => signOut(auth)}>Sign Out</button>
          <br /><br />
          <Link href="/inquiry">Contact Your Rep</Link>
        </>
      ) : (
        <>
          <Link href="/login">Login</Link> | <Link href="/register">Register</Link>
        </>
      )}
    </div>
  );
}